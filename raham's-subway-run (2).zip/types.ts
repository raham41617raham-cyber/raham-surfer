
export type Lane = number; // -1, 0, 1 are playable. -2, 2 etc are scenery

export enum GameState {
  START = 'START',
  INTRO = 'INTRO',
  PLAYING = 'PLAYING',
  GAME_OVER = 'GAME_OVER'
}

export enum EntityType {
  OBSTACLE_LOW = 'OBSTACLE_LOW', // Jumpable
  OBSTACLE_HIGH = 'OBSTACLE_HIGH', // Rollable or Slide around
  TRAIN = 'TRAIN', // Solid
  COIN = 'COIN',
  POWERUP_JETPACK = 'POWERUP_JETPACK',
  POWERUP_SNEAKERS = 'POWERUP_SNEAKERS',
  POWERUP_MAGNET = 'POWERUP_MAGNET',
  POWERUP_MULTIPLIER = 'POWERUP_MULTIPLIER',
  POWERUP_HOVERBOARD = 'POWERUP_HOVERBOARD',
  // Decorations
  DECO_BUILDING = 'DECO_BUILDING',
  DECO_LAMP = 'DECO_LAMP',
  DECO_PROP = 'DECO_PROP' // Tools/Trash/Boxes
}

export interface Entity {
  id: string;
  type: EntityType;
  lane: Lane;
  z: number; // Depth position. 0 is player, negative is far away
  active: boolean;
  collected?: boolean;
}

export interface PlayerState {
  lane: Lane; // Strict -1, 0, 1 for player
  y: number; // Vertical position (jump)
  z: number; // Usually 0, but jetpack moves forward visually
  isJumping: boolean;
  isRolling: boolean;
  verticalVelocity: number;
  activePowerups: {
    [key in EntityType]?: number; // timestamp when it expires
  };
  hoverboardEndTime?: number; // Timestamp when hoverboard expires
}

export interface GameMetrics {
  score: number;
  coins: number;
  distance: number;
  speed: number;
  multiplier: number;
}

export interface Character {
  id: string;
  name: string;
  cost: number;
  colorPrimary: string;
  colorSecondary: string;
  style: string;
}
