

export const LANE_WIDTH = 2; // World units
export const PLAYER_SPEED_INITIAL = 0.25; // Units per frame
export const GRAVITY = 0.02; // Increased gravity for snappier feel (was 0.015)
export const JUMP_FORCE = 0.42; // Increased jump force to clear hurdles on frame 1 (was 0.35)
export const LANE_SWITCH_SPEED = 0.3;
export const SPAWN_DISTANCE = 100;
export const DESPAWN_Z = 10; 
export const COLLISION_THRESHOLD = 0.6;

export const POWERUP_DURATION = 5000; // 5 Seconds (Collected in-game)
export const HOVERBOARD_DURATION = 10000; // 10 Seconds
export const MAGNET_DURATION_INVENTORY = 10000; // 10 Seconds (Activated from inventory)

export const COLORS = {
  primary: '#ec4899', // Pink-500
  secondary: '#06b6d4', // Cyan-500
  accent: '#facc15', // Yellow-400
  track: '#374151', // Gray-700
};

export const CHARACTERS = [
  { id: 'raham', name: 'Raham', cost: 0, colorPrimary: 'bg-gray-900', colorSecondary: 'bg-blue-800', style: 'HOODIE' },
  { id: 'blaze', name: 'Blaze', cost: 100, colorPrimary: 'bg-red-600', colorSecondary: 'bg-orange-500', style: 'SPORT' },
  { id: 'ninja', name: 'Shadow', cost: 500, colorPrimary: 'bg-black', colorSecondary: 'bg-zinc-800', style: 'NINJA' },
  { id: 'cyber', name: 'Cyber', cost: 1000, colorPrimary: 'bg-cyan-600', colorSecondary: 'bg-purple-600', style: 'CYBER' },
  { id: 'gold', name: 'Midas', cost: 5000, colorPrimary: 'bg-yellow-500', colorSecondary: 'bg-yellow-300', style: 'GOLD' },
];