
import { useEffect, useCallback } from 'react';
import { GameState } from '../types';

interface ControlsProps {
  onLeft: () => void;
  onRight: () => void;
  onJump: () => void;
  onRoll: () => void;
  onDoubleTap: () => void;
  onHoverboardKey: () => void;
  onMagnetKey: () => void;
  gameState: GameState;
}

export const useControls = ({ onLeft, onRight, onJump, onRoll, onDoubleTap, onHoverboardKey, onMagnetKey, gameState }: ControlsProps) => {
  useEffect(() => {
    if (gameState !== GameState.PLAYING) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
        case 'a':
          onLeft();
          break;
        case 'ArrowRight':
        case 'd':
          onRight();
          break;
        case 'ArrowUp':
        case 'w':
        case ' ':
          onJump();
          break;
        case 'ArrowDown':
        case 's':
          onRoll();
          break;
        case 'h':
        case 'H':
          onHoverboardKey();
          break;
        case 'm':
        case 'M':
          onMagnetKey();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, onLeft, onRight, onJump, onRoll, onHoverboardKey, onMagnetKey]);

  // Touch Handling
  useEffect(() => {
    if (gameState !== GameState.PLAYING) return;

    let touchStartX = 0;
    let touchStartY = 0;
    let lastTap = 0;

    const handleTouchStart = (e: TouchEvent) => {
      touchStartX = e.changedTouches[0].screenX;
      touchStartY = e.changedTouches[0].screenY;
      
      const now = Date.now();
      if (now - lastTap < 300) {
        onDoubleTap();
      }
      lastTap = now;
    };

    const handleTouchEnd = (e: TouchEvent) => {
      const touchEndX = e.changedTouches[0].screenX;
      const touchEndY = e.changedTouches[0].screenY;
      
      const diffX = touchEndX - touchStartX;
      const diffY = touchEndY - touchStartY;
      const absDiffX = Math.abs(diffX);
      const absDiffY = Math.abs(diffY);

      if (Math.max(absDiffX, absDiffY) < 30) return; // Tap/Ignore small movements

      if (absDiffX > absDiffY) {
        // Horizontal
        if (diffX > 0) onRight();
        else onLeft();
      } else {
        // Vertical
        if (diffY > 0) onRoll();
        else onJump();
      }
    };

    window.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchend', handleTouchEnd);
    return () => {
      window.removeEventListener('touchstart', handleTouchStart);
      window.removeEventListener('touchend', handleTouchEnd);
    };
  }, [gameState, onLeft, onRight, onJump, onRoll, onDoubleTap]);
};
