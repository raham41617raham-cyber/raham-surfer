
import React from 'react';
import { Entity, EntityType } from '../types';
import { Zap, Magnet, ChevronsUp, Shield, TriangleAlert } from 'lucide-react';

interface Props {
  entity: Entity;
  worldZ: number;
}

const EntityRenderer: React.FC<Props> = ({ entity }) => {
  const { type, lane, z } = entity;
  
  let visualX = lane * 120;
  if (Math.abs(lane) >= 2) {
      visualX = lane > 0 ? 300 : -300; 
  }

  const visualZ = z;

  if (visualZ < -5 || visualZ > 120) return null;

  const style: React.CSSProperties = {
    transform: `translate3d(${visualX}px, 0, ${-visualZ * 60}px)`,
    position: 'absolute',
    bottom: 0,
    left: '50%',
    marginLeft: '-50px', 
    width: '100px',
    height: '100px',
    transformStyle: 'preserve-3d',
    willChange: 'transform', 
    zIndex: Math.floor(10000 - (visualZ * 10)), 
  };

  switch (type) {
    case EntityType.TRAIN:
      return (
        <div style={{ ...style, height: '180px', width: '120px', marginLeft: '-60px' }} className="flex items-end justify-center">
            {/* Train Body - Bulkier and Rounded */}
            <div className="w-full h-44 bg-red-700 border-x-4 border-t-4 border-red-900 rounded-t-3xl relative shadow-2xl flex flex-col items-center justify-start overflow-hidden">
                {/* Roof Gradient */}
                <div className="w-full h-8 bg-gradient-to-b from-red-500 to-red-700 absolute top-0 rounded-t-2xl"></div>
                {/* Windshield */}
                <div className="w-28 h-20 bg-blue-900/90 border-4 border-gray-800 rounded-b-xl mt-6 relative overflow-hidden shadow-inner">
                    <div className="absolute top-0 right-0 w-full h-full bg-gradient-to-tr from-transparent via-white/30 to-transparent"></div>
                </div>
                {/* Logo / Number */}
                <div className="mt-2 text-yellow-400 font-black text-xs tracking-widest border border-yellow-400 px-1 rounded">METRO</div>
                {/* Lights */}
                <div className="absolute bottom-4 w-full flex justify-between px-6">
                     <div className="w-6 h-6 bg-yellow-200 rounded-full border-2 border-gray-600 shadow-[0_0_15px_rgba(253,224,71,0.8)] animate-pulse"></div>
                     <div className="w-6 h-6 bg-yellow-200 rounded-full border-2 border-gray-600 shadow-[0_0_15px_rgba(253,224,71,0.8)] animate-pulse"></div>
                </div>
                {/* Grille */}
                <div className="absolute bottom-0 w-full h-8 bg-gray-800 flex justify-center gap-1 pt-1">
                    <div className="w-1 h-full bg-black"></div>
                    <div className="w-1 h-full bg-black"></div>
                    <div className="w-1 h-full bg-black"></div>
                </div>
            </div>
            {/* Shadow */}
            <div className="absolute -bottom-1 w-32 h-6 bg-black/60 blur-md rounded-full transform scale-x-110"></div>
        </div>
      );
    case EntityType.OBSTACLE_LOW:
      return (
        <div style={{ ...style, height: '60px' }} className="flex items-end justify-center">
          <div className="relative w-28 h-16">
              <div className="absolute bottom-0 w-full h-full bg-amber-700 border-2 border-amber-900 rounded-lg flex items-center justify-center shadow-lg">
                <div className="w-full h-full border-t-4 border-b-4 border-dashed border-red-500/50 absolute"></div>
                <span className="text-white text-xs font-black uppercase tracking-widest bg-red-600 px-2 py-0.5 transform -rotate-2 rounded">DANGER</span>
              </div>
          </div>
        </div>
      );
    case EntityType.OBSTACLE_HIGH:
      return (
        <div style={{ ...style, height: '140px' }} className="flex items-end justify-center">
          <div className="relative w-28 h-40">
              <div className="w-full h-full bg-gray-800 rounded-lg border-4 border-gray-600 flex flex-col items-center justify-center overflow-hidden shadow-xl">
                 <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
                 <div className="w-20 h-20 rounded-full border-8 border-red-600 flex items-center justify-center">
                     <div className="w-full h-2 bg-red-600 transform -rotate-45"></div>
                 </div>
              </div>
              <div className="absolute bottom-0 -left-2 w-4 h-full bg-gray-700 -z-10"></div>
              <div className="absolute bottom-0 -right-2 w-4 h-full bg-gray-700 -z-10"></div>
          </div>
        </div>
      );
    case EntityType.COIN:
      return (
        <div style={{ ...style, transform: `translate3d(${visualX}px, -40px, ${-visualZ * 60}px)` }} className="flex items-center justify-center">
          <div className="relative w-12 h-12 preserve-3d animate-[spin_2s_linear_infinite]">
             <div className="absolute inset-0 bg-yellow-400 rounded-full border-[6px] border-yellow-600 flex items-center justify-center shadow-[0_0_15px_rgba(250,204,21,0.8)]">
                 <div className="w-8 h-8 rounded-full border border-yellow-200/50 flex items-center justify-center">
                     <span className="font-bold text-yellow-700 text-lg">$</span>
                 </div>
             </div>
          </div>
          <div className="absolute -bottom-10 w-8 h-2 bg-yellow-400/30 blur-md rounded-full animate-pulse"></div>
        </div>
      );
    
    // Decorations
    case EntityType.DECO_BUILDING:
        const height = (parseInt(entity.id.slice(-2), 36) % 5) * 40 + 200;
        const color = ['bg-gray-700', 'bg-slate-700', 'bg-neutral-700'][parseInt(entity.id.slice(-1), 36) % 3];
        return (
            <div style={{ ...style, width: '300px', height: `${height}px`, marginLeft: '-150px' }} className="flex items-end justify-center">
                <div className={`w-full h-full ${color} relative border-r-8 border-b-8 border-black/30 shadow-2xl`}>
                    <div className="absolute inset-2 grid grid-cols-4 gap-3 overflow-hidden">
                        {Array.from({ length: 16 }).map((_, i) => (
                            <div key={i} className={`w-full h-6 ${Math.random() > 0.4 ? 'bg-black/40' : 'bg-yellow-200/60'} rounded-sm`}></div>
                        ))}
                    </div>
                </div>
            </div>
        );
    case EntityType.DECO_LAMP:
        return (
             <div style={{ ...style, height: '220px' }} className="flex items-end justify-center">
                 <div className="w-3 h-full bg-green-900 relative rounded-full">
                     <div className="absolute top-2 left-0 w-16 h-4 bg-green-800 rounded-r-full flex items-center justify-end px-1">
                         <div className="w-8 h-8 bg-white/90 rounded-full shadow-[0_0_40px_rgba(255,255,255,0.9)] blur-[1px]"></div>
                     </div>
                 </div>
             </div>
        );
    case EntityType.DECO_PROP:
         const propType = parseInt(entity.id.slice(-1), 36) % 3;
         return (
             <div style={{ ...style, height: '60px' }} className="flex items-end justify-center">
                 {propType === 0 && ( 
                      <div className="w-12 h-16 bg-orange-500 rounded-lg border-2 border-orange-700 flex flex-col items-center justify-around py-2 shadow-lg">
                           <div className="w-full h-2 bg-white/90"></div>
                           <div className="w-full h-2 bg-white/90"></div>
                      </div>
                 )}
                 {propType === 1 && ( 
                      <div className="w-14 h-10 bg-red-800 rounded-t-lg border-2 border-red-950 relative shadow-md">
                          <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-8 h-2 bg-gray-400 rounded-full"></div>
                      </div>
                 )}
                 {propType === 2 && ( 
                      <div className="flex flex-col items-center">
                           <TriangleAlert size={40} className="text-yellow-400 fill-yellow-400/20 drop-shadow-md" />
                           <div className="w-2 h-8 bg-gray-600"></div>
                      </div>
                 )}
             </div>
         );

    // Powerups
    case EntityType.POWERUP_JETPACK:
        return <PowerupIcon style={style} visualX={visualX} visualZ={visualZ} icon={<Zap size={32} color="white" />} bg="bg-purple-600" />;
    case EntityType.POWERUP_SNEAKERS:
        return <PowerupIcon style={style} visualX={visualX} visualZ={visualZ} icon={<ChevronsUp size={32} color="white" />} bg="bg-orange-500" />;
    case EntityType.POWERUP_MAGNET:
        return <PowerupIcon style={style} visualX={visualX} visualZ={visualZ} icon={<Magnet size={32} color="white" />} bg="bg-blue-600" />;
    case EntityType.POWERUP_MULTIPLIER:
        return <PowerupIcon style={style} visualX={visualX} visualZ={visualZ} icon={<span className="text-white font-bold text-xl">2x</span>} bg="bg-green-600" />;
    case EntityType.POWERUP_HOVERBOARD:
        return <PowerupIcon style={style} visualX={visualX} visualZ={visualZ} icon={<Shield size={32} color="white" />} bg="bg-pink-600" />;
    default:
      return null;
  }
};

const PowerupIcon = ({ style, visualX, visualZ, icon, bg }: any) => (
    <div style={{ ...style, transform: `translate3d(${visualX}px, -40px, ${-visualZ * 60}px)` }} className="flex flex-col items-center justify-center">
        <div className={`w-14 h-14 ${bg} rounded-full border-4 border-white flex items-center justify-center shadow-[0_0_20px_rgba(255,255,255,0.6)] animate-bounce relative z-10`}>
            {icon}
        </div>
        <div className={`absolute bottom-0 w-12 h-4 bg-white/40 blur-md rounded-full`}></div>
    </div>
);

export default EntityRenderer;
