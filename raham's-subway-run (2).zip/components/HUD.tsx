
import React, { useEffect, useState } from 'react';
import { GameMetrics, GameState, EntityType } from '../types';
import { Pause, Play, Zap, Shield, Magnet, ChevronsUp } from 'lucide-react';

interface Props {
  metrics: GameMetrics;
  gameState: GameState;
  onPause: () => void;
  onResume: () => void;
  activePowerups: { [key in EntityType]?: number }; // End times
  hoverboardEndTime?: number;
  hoverboardCount: number;
  magnetCount: number;
}

const HUD: React.FC<Props> = ({ metrics, gameState, onPause, onResume, activePowerups, hoverboardEndTime, hoverboardCount, magnetCount }) => {
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
      if (gameState !== GameState.PLAYING) return;
      const interval = setInterval(() => setNow(Date.now()), 100);
      return () => clearInterval(interval);
  }, [gameState]);

  if (gameState === GameState.START || gameState === GameState.GAME_OVER) return null;

  const getStrokeColor = (bgClass: string) => {
      switch(bgClass) {
          case 'bg-pink-600': return '#db2777';
          case 'bg-purple-600': return '#9333ea';
          case 'bg-blue-600': return '#2563eb';
          case 'bg-orange-500': return '#f97316';
          case 'bg-green-600': return '#16a34a';
          default: return '#ffffff';
      }
  };

  const renderTimer = (icon: React.ReactNode, endTime: number | undefined, bgClass: string, maxDuration: number) => {
      if (!endTime || endTime < now) return null;
      
      const remainingMs = Math.max(0, endTime - now);
      const secondsLeft = Math.ceil(remainingMs / 1000);
      const progress = Math.min(1, remainingMs / maxDuration);
      
      const radius = 18;
      const circumference = 2 * Math.PI * radius;
      const strokeDashoffset = circumference * (1 - progress);
      const strokeColor = getStrokeColor(bgClass);

      return (
          <div className="flex items-center gap-3 mb-3 animate-in slide-in-from-left duration-300 bg-black/40 backdrop-blur-sm p-1 pr-4 rounded-full border border-white/10">
              <div className="relative w-10 h-10 flex items-center justify-center">
                   {/* Progress Ring */}
                   <svg className="absolute inset-0 w-full h-full -rotate-90 transform scale-110" viewBox="0 0 40 40">
                       <circle cx="20" cy="20" r={radius} fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="3" />
                       <circle 
                          cx="20" cy="20" r={radius} 
                          fill="none" 
                          stroke={strokeColor}
                          strokeWidth="3" 
                          strokeDasharray={circumference}
                          strokeDashoffset={strokeDashoffset}
                          strokeLinecap="round"
                          className="transition-[stroke-dashoffset] duration-100 linear"
                       />
                   </svg>
                   {/* Icon */}
                   <div className="relative z-10 text-white drop-shadow-md">
                       {React.cloneElement(icon as React.ReactElement, { size: 18 })}
                   </div>
              </div>
              <span className="font-black text-xl text-white font-mono min-w-[1.5rem] text-center">{secondsLeft}</span>
          </div>
      );
  };

  return (
    <div className="absolute inset-0 pointer-events-none p-4 flex flex-col justify-between">
      {/* Top Bar */}
      <div className="flex justify-between items-start">
        <div className="flex flex-col gap-2">
            <div className="bg-black/60 backdrop-blur-md p-2 rounded-lg border-2 border-pink-500 shadow-[0_0_10px_#ec4899] flex items-center gap-3">
                <span className="text-3xl font-black text-white italic tracking-tighter graffiti-text">{metrics.score.toLocaleString()}</span>
                {metrics.multiplier > 1 && (
                    <span className="bg-green-500 text-black font-bold text-xs px-1 rounded animate-bounce">x{metrics.multiplier}</span>
                )}
            </div>
            <div className="flex gap-2">
                 <div className="bg-yellow-500/80 p-1 px-3 rounded-full border border-white flex items-center gap-1">
                     <div className="w-4 h-4 bg-yellow-300 rounded-full border border-yellow-700"></div>
                     <span className="font-bold text-white text-sm">{metrics.coins}</span>
                 </div>
                 
                 {/* Available Hoverboards */}
                 <div className="bg-pink-600/80 p-1 px-3 rounded-full border border-white flex items-center gap-1">
                     <Shield size={16} className="fill-white text-white" />
                     <span className="font-bold text-white text-sm">{hoverboardCount}</span>
                 </div>

                 {/* Available Magnets */}
                 <div className="bg-blue-600/80 p-1 px-3 rounded-full border border-white flex items-center gap-1">
                     <Magnet size={16} className="fill-white text-white" />
                     <span className="font-bold text-white text-sm">{magnetCount}</span>
                 </div>
            </div>
        </div>

        <button 
            onClick={gameState === GameState.PLAYING ? onPause : onResume}
            className="pointer-events-auto bg-white/20 p-2 rounded-full hover:bg-white/40 transition-colors"
        >
            {gameState === GameState.PLAYING ? <Pause color="white" /> : <Play color="white" />}
        </button>
      </div>

      {/* Left Side: Active Powerup Timers */}
      <div className="absolute top-32 left-4 flex flex-col gap-2 pointer-events-auto">
         {renderTimer(<Shield className="text-white" />, hoverboardEndTime, 'bg-pink-600', 10000)}
         {renderTimer(<Zap className="text-white" />, activePowerups[EntityType.POWERUP_JETPACK], 'bg-purple-600', 5000)}
         {renderTimer(<Magnet className="text-white" />, activePowerups[EntityType.POWERUP_MAGNET], 'bg-blue-600', 10000)}
         {renderTimer(<ChevronsUp className="text-white" />, activePowerups[EntityType.POWERUP_SNEAKERS], 'bg-orange-500', 5000)}
         {renderTimer(<span className="font-bold text-white text-xs">2x</span>, activePowerups[EntityType.POWERUP_MULTIPLIER], 'bg-green-600', 5000)}
      </div>

    </div>
  );
};

export default HUD;
