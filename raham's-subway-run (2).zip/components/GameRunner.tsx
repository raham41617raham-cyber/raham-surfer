

import React, { useRef, useState, useEffect } from 'react';
import { GameState, PlayerState, Entity, EntityType, Lane, GameMetrics, Character } from '../types';
import { PLAYER_SPEED_INITIAL, GRAVITY, JUMP_FORCE, POWERUP_DURATION, HOVERBOARD_DURATION, MAGNET_DURATION_INVENTORY } from '../constants';
import EntityRenderer from './EntityRenderer';
import Player from './Player';
import { useControls } from '../hooks/useControls';

interface Props {
  gameState: GameState;
  onGameOver: (metrics: GameMetrics) => void;
  onScoreUpdate: (metrics: GameMetrics) => void;
  selectedCharacter: Character;
  onSync: (playerState: PlayerState) => void;
  availableHoverboards: number;
  onConsumeHoverboard: () => void;
  availableMagnets: number;
  onConsumeMagnet: () => void;
}

const GameRunner: React.FC<Props> = ({ gameState, onGameOver, onScoreUpdate, selectedCharacter, onSync, availableHoverboards, onConsumeHoverboard, availableMagnets, onConsumeMagnet }) => {
  // Game State Refs
  const scoreRef = useRef(0);
  const distanceRef = useRef(0);
  const coinsRef = useRef(0);
  const speedRef = useRef(PLAYER_SPEED_INITIAL);
  const requestRef = useRef<number>(0);
  const lastTimeRef = useRef<number | undefined>(undefined);
  
  // Entities
  const [entities, setEntities] = useState<Entity[]>([]);
  const entitiesRef = useRef<Entity[]>([]); 

  // Player State
  const [player, setPlayer] = useState<PlayerState>({
    lane: 0,
    y: 0,
    z: 0,
    isJumping: false,
    isRolling: false,
    verticalVelocity: 0,
    activePowerups: {},
    hoverboardEndTime: undefined,
  });
  const playerRef = useRef<PlayerState>(player);

  useEffect(() => {
    playerRef.current = player;
  }, [player]);

  // Controls
  const handleLeft = () => {
    setPlayer(prev => ({ ...prev, lane: Math.max(-1, prev.lane - 1) as Lane }));
  };
  const handleRight = () => {
    setPlayer(prev => ({ ...prev, lane: Math.min(1, prev.lane + 1) as Lane }));
  };
  const handleJump = () => {
    if (playerRef.current.isJumping && !playerRef.current.activePowerups.POWERUP_JETPACK) return;
    setPlayer(prev => ({ 
        ...prev, 
        isJumping: true, 
        verticalVelocity: prev.activePowerups.POWERUP_SNEAKERS ? JUMP_FORCE * 1.5 : JUMP_FORCE 
    }));
  };
  const handleRoll = () => {
     if (playerRef.current.activePowerups.POWERUP_JETPACK) {
         setPlayer(prev => ({ ...prev, isJumping: false, y: 0, verticalVelocity: 0 }));
         return;
     }
    setPlayer(prev => ({ ...prev, isRolling: true }));
    setTimeout(() => setPlayer(prev => ({ ...prev, isRolling: false })), 800);
    // Fast fall
    if (playerRef.current.isJumping) {
         setPlayer(prev => ({ ...prev, verticalVelocity: -JUMP_FORCE }));
    }
  };
  
  const activateHoverboard = () => {
      if (gameState !== GameState.PLAYING) return;
      if (playerRef.current.hoverboardEndTime && playerRef.current.hoverboardEndTime > Date.now()) return;

      if (availableHoverboards > 0) {
          onConsumeHoverboard();
          setPlayer(prev => ({ ...prev, hoverboardEndTime: Date.now() + HOVERBOARD_DURATION }));
      }
  };

  const activateMagnet = () => {
      if (gameState !== GameState.PLAYING) return;
      const currentExpiry = playerRef.current.activePowerups.POWERUP_MAGNET || 0;
      if (currentExpiry > Date.now() + 5000) return;

      if (availableMagnets > 0) {
          onConsumeMagnet();
          setPlayer(prev => ({ 
              ...prev, 
              activePowerups: {
                  ...prev.activePowerups,
                  [EntityType.POWERUP_MAGNET]: Date.now() + MAGNET_DURATION_INVENTORY
              }
          }));
      }
  };

  useControls({
    onLeft: handleLeft,
    onRight: handleRight,
    onJump: handleJump,
    onRoll: handleRoll,
    onDoubleTap: activateHoverboard,
    onHoverboardKey: activateHoverboard,
    onMagnetKey: activateMagnet,
    gameState
  });

  // Smart Spawn Logic
  const spawnObstacles = (currentDistance: number) => {
    const spawnZ = 120;
    
    // --- MAIN LANE OBSTACLES (Lanes -1, 0, 1) ---
    if (Math.random() < 0.08) {
      const activeLanes = entitiesRef.current
        .filter(e => e.z > spawnZ - 10 && e.z < spawnZ + 10 && Math.abs(e.lane) <= 1)
        .map(e => e.lane);

      // Try to pick a free lane
      const allLanes: Lane[] = [-1, 0, 1];
      const freeLanes = allLanes.filter(l => !activeLanes.includes(l));
      
      if (freeLanes.length > 0) {
        const lane = freeLanes[Math.floor(Math.random() * freeLanes.length)];
        
        const r = Math.random();
        let type = EntityType.OBSTACLE_LOW;
        
        if (r > 0.85) type = EntityType.TRAIN;
        else if (r > 0.65) type = EntityType.OBSTACLE_HIGH;
        else if (r > 0.4) type = EntityType.COIN;
        else if (r > 0.38) {
            const pups = [EntityType.POWERUP_JETPACK, EntityType.POWERUP_SNEAKERS, EntityType.POWERUP_MAGNET, EntityType.POWERUP_MULTIPLIER, EntityType.POWERUP_HOVERBOARD];
            type = pups[Math.floor(Math.random() * pups.length)];
        } else {
            type = EntityType.COIN;
        }

        const collision = entitiesRef.current.some(e => e.lane === lane && Math.abs(e.z - spawnZ) < 5);
        if (!collision) {
            const newEntity: Entity = {
                id: Math.random().toString(36).substr(2, 9),
                type,
                lane,
                z: spawnZ,
                active: true
            };
            
            if (type === EntityType.COIN && Math.random() > 0.5) {
                // Arc of coins or line
                for(let i=0; i<5; i++) {
                    entitiesRef.current.push({
                        id: Math.random().toString(36).substr(2, 9),
                        type: EntityType.COIN,
                        lane,
                        z: spawnZ + (i * 3),
                        active: true
                    });
                }
            } else {
                entitiesRef.current.push(newEntity);
            }
        }
      }
    }

    // --- SIDE DECORATIONS (Lanes -2, 2) ---
    if (Math.random() < 0.2) {
       if (!entitiesRef.current.some(e => e.lane === -2 && Math.abs(e.z - spawnZ) < 15)) {
           const decoType = Math.random() > 0.5 ? EntityType.DECO_BUILDING : (Math.random() > 0.5 ? EntityType.DECO_LAMP : EntityType.DECO_PROP);
           entitiesRef.current.push({
               id: 'deco-left-' + Math.random(),
               type: decoType,
               lane: -2,
               z: spawnZ,
               active: true
           });
       }
       if (!entitiesRef.current.some(e => e.lane === 2 && Math.abs(e.z - spawnZ) < 15)) {
           const decoType = Math.random() > 0.5 ? EntityType.DECO_BUILDING : (Math.random() > 0.5 ? EntityType.DECO_LAMP : EntityType.DECO_PROP);
           entitiesRef.current.push({
               id: 'deco-right-' + Math.random(),
               type: decoType,
               lane: 2,
               z: spawnZ,
               active: true
           });
       }
    }
  };

  const update = (time: number) => {
    if (lastTimeRef.current === undefined) lastTimeRef.current = time;
    const deltaTime = time - lastTimeRef.current;
    lastTimeRef.current = time;

    let p = playerRef.current;
    let newY = p.y;
    let newVel = p.verticalVelocity;
    
    // Check Powerup Expirations
    const now = Date.now();
    let powerupsChanged = false;
    const nextPowerups = { ...p.activePowerups };
    Object.keys(nextPowerups).forEach(key => {
        const k = key as EntityType;
        if (nextPowerups[k] && nextPowerups[k]! < now) {
            delete nextPowerups[k];
            powerupsChanged = true;
        }
    });

    let nextHoverboard = p.hoverboardEndTime;
    if (nextHoverboard && nextHoverboard < now) {
        nextHoverboard = undefined;
        powerupsChanged = true;
    }

    if (powerupsChanged) {
        setPlayer(prev => ({ ...prev, activePowerups: nextPowerups, hoverboardEndTime: nextHoverboard }));
        p = { ...p, activePowerups: nextPowerups, hoverboardEndTime: nextHoverboard };
    }

    if (p.activePowerups.POWERUP_JETPACK) {
        newY = 5; 
        newVel = 0;
    } else if (p.isJumping) {
        newY += newVel;
        newVel -= GRAVITY;
        if (newY <= 0) {
            newY = 0;
            newVel = 0;
            if (p.isJumping) {
                setPlayer(prev => ({ ...prev, isJumping: false, y: 0, verticalVelocity: 0 }));
            }
        } else {
             setPlayer(prev => ({ ...prev, y: newY, verticalVelocity: newVel }));
        }
    }

    const moveSpeed = speedRef.current * (deltaTime / 16);
    
    entitiesRef.current.forEach(e => {
        e.z -= moveSpeed;
        
        // Magnet
        if (p.activePowerups.POWERUP_MAGNET && e.type === EntityType.COIN && e.z < 20 && e.z > -5) {
             const laneDiff = p.lane - e.lane;
             if (Math.abs(laneDiff) > 0.1) {
                 e.lane += (laneDiff * 0.15) as any;
             }
             if (e.z > 0) e.z -= 0.5;
        }
    });

    // Collision
    entitiesRef.current.forEach(e => {
        if (!e.active || e.collected) return;
        if (Math.abs(e.lane) >= 2) return;

        if (e.z < 1.0 && e.z > -0.8) {
            const laneMatch = Math.abs(e.lane - p.lane) < 0.6;
            
            if (laneMatch) {
                if (e.type === EntityType.COIN) {
                    e.collected = true;
                    coinsRef.current += 1;
                    scoreRef.current += 10;
                } else if (e.type.startsWith('POWERUP')) {
                    e.collected = true;
                    const type = e.type as EntityType;
                    
                    if (type === EntityType.POWERUP_HOVERBOARD) {
                        setPlayer(prev => ({ ...prev, hoverboardEndTime: Date.now() + HOVERBOARD_DURATION }));
                    } else {
                        setPlayer(prev => ({
                            ...prev,
                            activePowerups: { ...prev.activePowerups, [type]: Date.now() + POWERUP_DURATION }
                        }));
                    }

                } else {
                    const isFlying = !!p.activePowerups.POWERUP_JETPACK;
                    if (isFlying) return;

                    let hit = false;
                    
                    // Use newY for collision logic to ensure frame-perfect jumping
                    if (e.type === EntityType.TRAIN) {
                         if (newY < 2.5) hit = true; 
                    } else if (e.type === EntityType.OBSTACLE_LOW) {
                         // Threshold lowered to 0.3 so first frame of jump clears it
                         if (newY < 0.3) hit = true; 
                    } else if (e.type === EntityType.OBSTACLE_HIGH) {
                         if (!p.isRolling) hit = true;
                    }

                    if (hit) {
                        if (p.hoverboardEndTime && p.hoverboardEndTime > Date.now()) {
                            setPlayer(prev => ({ ...prev, hoverboardEndTime: undefined }));
                            e.active = false;
                        } else {
                            onGameOver({
                                score: Math.floor(scoreRef.current),
                                coins: coinsRef.current,
                                distance: Math.floor(distanceRef.current),
                                speed: speedRef.current,
                                multiplier: playerRef.current.activePowerups.POWERUP_MULTIPLIER ? 2 : 1
                            });
                        }
                    }
                }
            }
        }
    });

    entitiesRef.current = entitiesRef.current.filter(e => e.z > -10 && !e.collected);
    distanceRef.current += moveSpeed;
    scoreRef.current += (moveSpeed * 10) * (playerRef.current.activePowerups.POWERUP_MULTIPLIER ? 2 : 1);
    speedRef.current = Math.min(0.7, PLAYER_SPEED_INITIAL + (distanceRef.current * 0.00002));

    spawnObstacles(distanceRef.current);
    setEntities([...entitiesRef.current]);
    onScoreUpdate({
        score: Math.floor(scoreRef.current),
        coins: coinsRef.current,
        distance: Math.floor(distanceRef.current),
        speed: speedRef.current,
        multiplier: playerRef.current.activePowerups.POWERUP_MULTIPLIER ? 2 : 1
    });
  };

  useEffect(() => {
    if (gameState === GameState.PLAYING) {
        lastTimeRef.current = undefined;
        const loop = (time: number) => {
             update(time);
             if (gameState === GameState.PLAYING) {
                 requestRef.current = requestAnimationFrame(loop);
             }
        };
        requestRef.current = requestAnimationFrame(loop);
    }
    return () => {
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState]);

  // Dynamic track positioning
  // Calculate offset to simulate movement of the floor texture
  const trackOffset = (distanceRef.current * 60) % 100; // 60px/unit scaling, mod 100px texture height

  // Guard Logic: Show if speed is low (start) or just started
  const showGuard = distanceRef.current < 50;

  return (
    <div className="perspective-container w-full h-full relative bg-gray-900 overflow-hidden">
      {/* Sky / City Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-400 via-blue-200 to-gray-200">
          <div className="absolute bottom-1/3 left-0 w-full h-64 opacity-60"
               style={{
                   backgroundImage: 'url("https://www.transparenttextures.com/patterns/city-lights.png")',
                   backgroundSize: '50% auto',
                   backgroundPosition: `${-distanceRef.current * 0.2}px 0`
               }} />
          {/* Distant skyline silhouettes could be added here */}
      </div>

      <div className="world-3d relative origin-bottom" style={{ perspectiveOrigin: '50% 25%', transform: 'scale(1.3)' }}>
        
        {/* Infinite Track Floor */}
        <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 w-[600px] h-[2000px] origin-top track-floor"
            style={{
                transform: 'rotateX(90deg) translateY(-20px)', // Flat on ground, pushed down slightly
                backgroundPosition: `0px ${trackOffset}px`,
                willChange: 'background-position'
            }}
        >
            {/* Fade to fog */}
            <div className="absolute top-0 w-full h-[1500px] bg-gradient-to-b from-blue-200 via-transparent to-transparent"></div>
        </div>

        {/* Entities */}
        {entities.map(e => (
            <EntityRenderer key={e.id} entity={e} worldZ={0} />
        ))}

        {/* Player */}
        <Player player={player} character={selectedCharacter} showGuard={showGuard} />
      </div>

      {speedRef.current > 0.5 && (
          <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(circle_at_center,transparent_0%,white_100%)] animate-pulse" />
      )}
      
      <GameSync player={player} onSync={onSync} />
    </div>
  );
};

const GameSync = ({ player, onSync }: { player: PlayerState, onSync: (p: PlayerState) => void }) => {
    const powerupsStr = JSON.stringify(player.activePowerups);
    useEffect(() => {
        onSync(player);
    }, [powerupsStr, player.hoverboardEndTime, onSync]);
    return null;
}

export default GameRunner;