
import React from 'react';
import { PlayerState, Character } from '../types';

interface Props {
  player: PlayerState;
  character: Character;
  showGuard?: boolean; // New prop to show guard when speed is low or stumbled
}

const Player: React.FC<Props> = ({ player, character, showGuard = false }) => {
  const { lane, y, isRolling, isJumping, activePowerups, hoverboardEndTime } = player;
  
  const hasHoverboard = hoverboardEndTime && hoverboardEndTime > Date.now();
  const isFlying = activePowerups.POWERUP_JETPACK;

  // Visual X Calculation: 120px per lane (Standardized with EntityRenderer)
  const visualX = lane * 120; 
  
  // Height calculation for jump: 1 unit = 60px visual height
  const visualY = y * 60; 

  // Shadow calculation: shrinks as player goes higher
  const shadowScale = Math.max(0.2, 1 - (y / 5));
  const shadowOpacity = Math.max(0, 0.6 - (y / 8));

  const style: React.CSSProperties = {
    transform: `translate3d(${visualX}px, ${-visualY}px, 0px)`,
    transition: 'transform 0.1s linear',
    position: 'absolute',
    bottom: '20px', // Base offset from track
    left: '50%',
    marginLeft: '-30px', // Half width (60px total)
    width: '60px',
    height: isRolling ? '60px' : '100px',
    zIndex: 10000, // Player always on top of obstacles at same Z
    willChange: 'transform',
  };

  const shadowStyle: React.CSSProperties = {
      transform: `translate3d(${visualX}px, 0px, 0px) scale(${shadowScale})`,
      opacity: shadowOpacity,
      position: 'absolute',
      bottom: '10px',
      left: '50%',
      marginLeft: '-30px',
      width: '60px',
      height: '10px',
      backgroundColor: 'black',
      borderRadius: '50%',
      filter: 'blur(4px)',
      zIndex: 9999,
      transition: 'transform 0.1s linear, opacity 0.1s linear'
  };

  return (
    <>
      {/* Dynamic Shadow on Ground */}
      <div style={shadowStyle} />

      {/* The Guard (Chaser) - Appears behind player */}
      {showGuard && !isFlying && (
          <div 
             className="absolute"
             style={{
                 transform: `translate3d(${visualX}px, 0, 150px)`, // 150px behind player
                 bottom: '20px',
                 left: '50%',
                 marginLeft: '-40px',
                 width: '80px',
                 height: '110px',
                 zIndex: 9998,
                 transition: 'transform 0.1s linear',
             }}
          >
              {/* Guard Body */}
              <div className="w-full h-full relative animate-[bounce_0.3s_infinite]">
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-14 h-14 bg-blue-900 rounded-full border-4 border-black z-20">
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-6 bg-black rounded-sm"></div> {/* Hat Rim */}
                      <div className="absolute top-5 left-1/2 -translate-x-1/2 w-10 h-3 bg-amber-300 rounded-sm"></div> {/* Face */}
                  </div>
                  <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-20 h-20 bg-blue-800 rounded-t-3xl border-4 border-black z-10 flex flex-col items-center">
                      <div className="mt-8 w-4 h-4 bg-yellow-400 rounded-full shadow-md"></div> {/* Badge */}
                  </div>
                  {/* Arms */}
                  <div className="absolute top-10 -left-2 w-6 h-16 bg-blue-900 rounded-full animate-run-l"></div>
                  <div className="absolute top-10 -right-2 w-6 h-16 bg-blue-900 rounded-full animate-run-r"></div>
              </div>
              
              {/* The Dog */}
              <div className="absolute -right-16 bottom-0 w-16 h-12 bg-white rounded-xl border-2 border-black animate-[bounce_0.2s_infinite_0.1s]">
                  <div className="absolute -top-4 left-0 w-8 h-8 bg-white rounded-full border-2 border-black">
                       <div className="absolute top-2 left-2 w-2 h-2 bg-black rounded-full"></div>
                       <div className="absolute -top-2 left-0 w-4 h-6 bg-black rounded-t-full origin-bottom rotate-12"></div>
                  </div>
              </div>
          </div>
      )}

      {/* Player Container */}
      <div style={style} className="relative">
         {/* Hoverboard visual */}
         {hasHoverboard && (
             <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-28 h-8 bg-pink-600 rounded-full border-2 border-white shadow-[0_0_20px_#ec4899] animate-pulse flex items-center justify-center transform rotate-x-12">
                 <div className="w-20 h-full bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 rounded-full opacity-80"></div>
                 <div className="absolute bottom-0 w-full h-2 bg-pink-800 rounded-full blur-sm"></div>
                 {/* Thrusters */}
                 <div className="absolute -bottom-2 left-4 w-4 h-6 bg-cyan-400 blur-sm opacity-80"></div>
                 <div className="absolute -bottom-2 right-4 w-4 h-6 bg-cyan-400 blur-sm opacity-80"></div>
             </div>
         )}

        {/* Character Body */}
        <div className={`w-full h-full transition-all duration-150 ${isRolling ? 'scale-y-75 origin-bottom' : ''}`}>
          
          {/* Head */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-12 bg-amber-200 rounded-xl z-20 shadow-md transform rotate-x-6">
              {/* Cap / Helmet */}
              {character.style === 'NINJA' ? (
                <div className="absolute inset-0 bg-black rounded-xl">
                   <div className="absolute top-3 left-1 w-10 h-4 bg-amber-200 rounded-sm"></div>
                   <div className="absolute top-3 -right-2 w-2 h-8 bg-red-600"></div> 
                </div>
              ) : character.style === 'CYBER' ? (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-14 h-8 bg-purple-500 rounded-t-xl border-b-2 border-cyan-400"></div>
              ) : (
                <>
                    <div className={`absolute -top-3 left-1/2 -translate-x-1/2 w-14 h-8 ${character.colorSecondary} rounded-t-xl transform -skew-x-6 border-b-2 border-black/30`}></div>
                    <div className={`absolute top-1 -right-3 w-8 h-3 ${character.colorSecondary} transform rotate-12 rounded-sm border-b border-black/30 shadow-sm`}></div>
                </>
              )}
              
              {/* Face */}
              {!['NINJA'].includes(character.style) && (
                <>
                  <div className="absolute top-4 left-1/2 -translate-x-1/2 w-10 h-3 bg-black/90 rounded-sm"></div> {/* Glasses */}
                  <div className="absolute top-4 left-1 w-1 h-3 bg-white/30 rounded-sm"></div> {/* Glare */}
                </>
              )}
          </div>

          {/* Torso */}
          <div className={`absolute top-11 left-1/2 -translate-x-1/2 w-14 h-16 ${character.colorPrimary} rounded-lg z-10 flex flex-col items-center shadow-lg overflow-hidden`}>
              {/* Outfit details */}
              <div className="w-full h-full bg-gradient-to-b from-transparent to-black/40"></div>
              <div className="absolute top-2 w-8 h-8 rounded-full border-4 border-white/20 opacity-50"></div>
              <div className="absolute mt-4 text-[8px] text-white/80 font-black tracking-widest z-10 graffiti-text">{character.name.toUpperCase()}</div>
              
              {/* Backpack (Jetpack) */}
              {activePowerups.POWERUP_JETPACK && (
                  <div className="absolute -top-4 -right-6 w-8 h-20 bg-gray-300 rounded-md border-2 border-gray-500 flex flex-col items-center shadow-xl">
                      <div className="w-6 h-16 bg-gradient-to-b from-gray-400 to-gray-600 rounded-sm border border-gray-400"></div>
                      <div className="absolute -bottom-4 w-full flex justify-center gap-1">
                          <div className="w-2 h-8 bg-orange-500 blur-sm animate-pulse"></div>
                          <div className="w-2 h-8 bg-orange-500 blur-sm animate-pulse"></div>
                      </div>
                  </div>
              )}
          </div>

          {/* Arms (Animated) */}
          <div className={`absolute top-12 -left-2 w-4 h-14 ${character.colorPrimary} rounded-full origin-top ${(!isRolling && !isJumping && !hasHoverboard) ? 'animate-run-r' : 'transform rotate-12'}`}></div>
          <div className={`absolute top-12 -right-2 w-4 h-14 ${character.colorPrimary} rounded-full origin-top ${(!isRolling && !isJumping && !hasHoverboard) ? 'animate-run-l' : 'transform -rotate-12'}`}></div>

          {/* Legs (Animated) */}
          {!activePowerups.POWERUP_JETPACK && (
              <>
                  <div className={`absolute bottom-0 left-3 w-5 h-16 ${character.colorSecondary} rounded-b-lg border-l border-black/20 origin-top ${isJumping || hasHoverboard ? 'transform -rotate-12' : 'animate-run-l'}`}></div>
                  <div className={`absolute bottom-0 right-3 w-5 h-16 ${character.colorSecondary} rounded-b-lg border-r border-black/20 origin-top ${isJumping || hasHoverboard ? 'transform rotate-12' : 'animate-run-r'}`}></div>
              </>
          )}

          {/* Shoes (Super Sneakers) */}
          {activePowerups.POWERUP_SNEAKERS && (
              <div className="absolute -bottom-3 w-full flex justify-between px-0">
                  <div className="w-8 h-8 bg-orange-500 rounded-lg border-2 border-white shadow-[0_0_10px_orange] animate-bounce"></div>
                  <div className="w-8 h-8 bg-orange-500 rounded-lg border-2 border-white shadow-[0_0_10px_orange] animate-bounce delay-75"></div>
              </div>
          )}

          {/* Magnet Effect */}
          {activePowerups.POWERUP_MAGNET && (
              <div className="absolute inset-0 border-4 border-blue-400 rounded-full opacity-60 animate-ping"></div>
          )}
        </div>
      </div>
    </>
  );
};

export default Player;
