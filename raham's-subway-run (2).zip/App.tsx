
import React, { useState, useEffect } from 'react';
import GameRunner from './components/GameRunner';
import HUD from './components/HUD';
import { GameState, GameMetrics, EntityType } from './types';
import { CHARACTERS } from './constants';
import { Play, RotateCcw, PaintBucket, Trophy, User, Lock, ShoppingCart, Shield, Plus, Magnet, Trash2 } from 'lucide-react';

const App = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.START);
  const [metrics, setMetrics] = useState<GameMetrics>({ score: 0, coins: 0, distance: 0, speed: 0, multiplier: 1 });
  
  // Powerup State for HUD
  const [activePowerups, setActivePowerups] = useState<{ [key in EntityType]?: number }>({});
  const [hoverboardEndTime, setHoverboardEndTime] = useState<number | undefined>(undefined);

  // Persistent State
  const [highScore, setHighScore] = useState(0);
  const [totalCoins, setTotalCoins] = useState(0);
  const [hoverboardCount, setHoverboardCount] = useState(5);
  const [magnetCount, setMagnetCount] = useState(5); // Default start with 5
  const [ownedChars, setOwnedChars] = useState<string[]>(['raham']);
  const [selectedCharId, setSelectedCharId] = useState('raham');

  // UI State
  const [showShop, setShowShop] = useState(false);
  const [gameId, setGameId] = useState(0);

  useEffect(() => {
     const storedScore = localStorage.getItem('raham_highscore');
     if (storedScore) setHighScore(parseInt(storedScore));

     const storedCoins = localStorage.getItem('raham_total_coins');
     if (storedCoins) setTotalCoins(parseInt(storedCoins));

     const storedHoverboards = localStorage.getItem('raham_hoverboards');
     if (storedHoverboards) setHoverboardCount(parseInt(storedHoverboards));

     const storedMagnets = localStorage.getItem('raham_magnets');
     if (storedMagnets) setMagnetCount(parseInt(storedMagnets));

     const storedChars = localStorage.getItem('raham_owned_chars');
     if (storedChars) setOwnedChars(JSON.parse(storedChars));

     const storedSel = localStorage.getItem('raham_selected_char');
     if (storedSel && CHARACTERS.find(c => c.id === storedSel)) setSelectedCharId(storedSel);
  }, []);

  const saveCoins = (newTotal: number) => {
      setTotalCoins(newTotal);
      localStorage.setItem('raham_total_coins', newTotal.toString());
  };

  const saveHoverboards = (count: number) => {
      setHoverboardCount(count);
      localStorage.setItem('raham_hoverboards', count.toString());
  };

  const saveMagnets = (count: number) => {
      setMagnetCount(count);
      localStorage.setItem('raham_magnets', count.toString());
  };

  const resetProgress = () => {
      if (window.confirm("RESET GAME DATA?\nThis will clear all coins, characters, inventory and high scores.\n\nThe game will reload.")) {
          localStorage.removeItem('raham_highscore');
          localStorage.removeItem('raham_total_coins');
          localStorage.removeItem('raham_hoverboards');
          localStorage.removeItem('raham_magnets');
          localStorage.removeItem('raham_owned_chars');
          localStorage.removeItem('raham_selected_char');

          // Force reload to ensure a completely clean state
          window.location.reload();
      }
  };

  const handleScoreUpdate = (newMetrics: GameMetrics) => {
    setMetrics(newMetrics);
  };
  
  // Syncs powerup timers from game engine to HUD
  const handleGameSync = (playerState: any) => {
      setActivePowerups(playerState.activePowerups);
      setHoverboardEndTime(playerState.hoverboardEndTime);
  };

  const handleGameOver = (finalMetrics: GameMetrics) => {
      setGameState(GameState.GAME_OVER);
      setMetrics(finalMetrics); // Ensure UI shows final stats
      
      // Save High Score
      if (finalMetrics.score > highScore) {
          setHighScore(finalMetrics.score);
          localStorage.setItem('raham_highscore', finalMetrics.score.toString());
      }

      // Add collected coins to total and persist
      if (finalMetrics.coins > 0) {
          // Use callback to ensure we have latest state if multiple updates occur
          setTotalCoins(prev => {
              const newTotal = prev + finalMetrics.coins;
              localStorage.setItem('raham_total_coins', newTotal.toString());
              return newTotal;
          });
      }
  };

  const startGame = () => {
    setMetrics({ score: 0, coins: 0, distance: 0, speed: 0, multiplier: 1 });
    setActivePowerups({});
    setHoverboardEndTime(undefined);
    setGameId(prev => prev + 1);
    setGameState(GameState.PLAYING);
  };

  const buyCharacter = (charId: string, cost: number) => {
      if (totalCoins >= cost) {
          saveCoins(totalCoins - cost);
          const newOwned = [...ownedChars, charId];
          setOwnedChars(newOwned);
          localStorage.setItem('raham_owned_chars', JSON.stringify(newOwned));
          setSelectedCharId(charId);
          localStorage.setItem('raham_selected_char', charId);
      }
  };

  const buyHoverboard = () => {
      const cost = 100;
      if (totalCoins >= cost) {
          saveCoins(totalCoins - cost);
          saveHoverboards(hoverboardCount + 1);
      }
  };

  const buyMagnet = () => {
      const cost = 100; // Updated to 100
      if (totalCoins >= cost) {
          saveCoins(totalCoins - cost);
          saveMagnets(magnetCount + 1);
      }
  };

  const onConsumeHoverboard = () => {
      if (hoverboardCount > 0) {
          saveHoverboards(hoverboardCount - 1);
      }
  };

  const onConsumeMagnet = () => {
      if (magnetCount > 0) {
          saveMagnets(magnetCount - 1);
      }
  };

  const selectCharacter = (charId: string) => {
      setSelectedCharId(charId);
      localStorage.setItem('raham_selected_char', charId);
  };

  const selectedCharacter = CHARACTERS.find(c => c.id === selectedCharId) || CHARACTERS[0];

  return (
    <div className="w-full h-screen bg-black overflow-hidden relative select-none font-sans">
      
      {/* Game Layer */}
      <div className={`w-full h-full transition-opacity duration-500 ${gameState === GameState.START ? 'opacity-30 blur-sm' : 'opacity-100'}`}>
          <GameRunner 
             key={gameId}
             gameState={gameState}
             onGameOver={handleGameOver}
             onScoreUpdate={handleScoreUpdate}
             onSync={handleGameSync}
             selectedCharacter={selectedCharacter}
             availableHoverboards={hoverboardCount}
             onConsumeHoverboard={onConsumeHoverboard}
             availableMagnets={magnetCount}
             onConsumeMagnet={onConsumeMagnet}
          />
      </div>

      {/* UI Overlay Layer */}
      <HUD 
        metrics={metrics} 
        gameState={gameState} 
        onPause={() => setGameState(GameState.INTRO)} 
        onResume={() => setGameState(GameState.PLAYING)}
        activePowerups={activePowerups}
        hoverboardEndTime={hoverboardEndTime}
        hoverboardCount={hoverboardCount}
        magnetCount={magnetCount}
      />

      {/* Main Menu Screen */}
      {gameState === GameState.START && !showShop && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-purple-900/80 via-black/80 to-pink-900/80 backdrop-blur-sm z-50">
            
            {/* Reset Button - Increased Z-Index and ensured clickability */}
            <button 
                onClick={resetProgress}
                className="absolute top-6 right-6 p-3 bg-red-600/20 hover:bg-red-600 hover:text-white text-red-500 rounded-full border-2 border-red-500 transition-all z-[100] group cursor-pointer active:scale-95"
                title="Reset All Progress"
            >
                <Trash2 size={24} />
            </button>

            <div className="relative group animate-float">
                 <h1 className="text-6xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-pink-500 to-yellow-400 italic transform -rotate-6 graffiti-text pb-4 pl-4 drop-shadow-[0_5px_5px_rgba(0,0,0,0.8)]">
                    Raham's
                    <br />
                    <span className="text-white ml-8 md:ml-16 text-5xl md:text-8xl">Subway Run</span>
                 </h1>
                 <div className="absolute -top-10 -right-10 animate-bounce">
                     <PaintBucket size={80} className="text-pink-500 drop-shadow-[0_0_25px_rgba(236,72,153,1)]" />
                 </div>
            </div>
            
            <p className="text-white/80 font-bold mt-4 tracking-widest uppercase text-sm border-b border-pink-500 pb-1">Made by Raham</p>
            
            {/* Stats Row */}
            <div className="flex gap-4 mt-8 flex-wrap justify-center">
                {/* Total Coins Display */}
                <div className="bg-yellow-500/90 text-black px-6 py-2 rounded-full font-black text-2xl border-4 border-yellow-700 shadow-lg flex items-center gap-2 transform hover:scale-105 transition-transform">
                     <div className="w-8 h-8 rounded-full bg-yellow-400 border-2 border-yellow-700 flex items-center justify-center shadow-inner relative overflow-hidden">
                         <span className="text-yellow-800 font-bold text-xs">$</span>
                         <div className="absolute top-0 right-0 w-3 h-3 bg-white/50 rounded-full blur-[1px]"></div>
                     </div>
                     {totalCoins.toLocaleString()}
                </div>

                {/* Hoverboard Inventory */}
                <div className="bg-pink-600/90 text-white px-4 py-2 rounded-full font-black text-xl border-4 border-pink-800 shadow-lg flex items-center gap-2">
                    <Shield size={24} className="fill-white" />
                    <span>{hoverboardCount}</span>
                    <button 
                        onClick={buyHoverboard}
                        disabled={totalCoins < 100}
                        className={`ml-2 w-8 h-8 rounded-full flex items-center justify-center border-2 border-white/50 hover:bg-white hover:text-pink-600 transition-colors ${totalCoins < 100 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                    >
                        <Plus size={16} strokeWidth={4} />
                    </button>
                    <span className="text-[10px] ml-1 opacity-80">100$</span>
                </div>

                 {/* Magnet Inventory */}
                 <div className="bg-blue-600/90 text-white px-4 py-2 rounded-full font-black text-xl border-4 border-blue-800 shadow-lg flex items-center gap-2">
                    <Magnet size={24} className="fill-white" />
                    <span>{magnetCount}</span>
                    <button 
                        onClick={buyMagnet}
                        disabled={totalCoins < 100} 
                        className={`ml-2 w-8 h-8 rounded-full flex items-center justify-center border-2 border-white/50 hover:bg-white hover:text-blue-600 transition-colors ${totalCoins < 100 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                    >
                        <Plus size={16} strokeWidth={4} />
                    </button>
                    <span className="text-[10px] ml-1 opacity-80">100$</span>
                </div>
            </div>

            <div className="mt-12 flex gap-6">
                <button 
                    onClick={startGame}
                    className="group relative px-12 py-5 bg-yellow-400 hover:bg-yellow-300 text-black font-black text-3xl uppercase tracking-widest skew-x-[-10deg] shadow-[8px_8px_0px_#000] transition-all hover:-translate-y-1 active:translate-y-1 hover:shadow-[12px_12px_0px_#ec4899]"
                >
                    <span className="flex items-center gap-3">
                        Start Run <Play fill="black" size={28} />
                    </span>
                </button>

                <button 
                    onClick={() => setShowShop(true)}
                    className="group relative px-8 py-5 bg-cyan-500 hover:bg-cyan-400 text-black font-black text-3xl uppercase tracking-widest skew-x-[-10deg] shadow-[8px_8px_0px_#000] transition-all hover:-translate-y-1 active:translate-y-1 hover:shadow-[12px_12px_0px_#0e7490]"
                >
                     <User size={32} />
                </button>
            </div>
            
            {highScore > 0 && (
                <div className="mt-8 flex items-center gap-2 text-cyan-300 font-bold text-xl border-2 border-cyan-500/50 p-2 px-8 rounded-full bg-black/60 shadow-lg">
                    <Trophy size={24} className="text-yellow-400" /> High Score: {highScore.toLocaleString()}
                </div>
            )}

            <div className="absolute bottom-10 text-gray-400 text-sm text-center font-mono bg-black/50 p-2 rounded">
                <p>Arrow Keys/Swipe to Move • Press 'H' for Hoverboard (10s) • Press 'M' for Magnet (10s)</p>
            </div>
        </div>
      )}

      {/* Shop Screen */}
      {showShop && (
           <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900/95 z-50 p-8">
               <div className="w-full max-w-4xl h-full flex flex-col">
                   <div className="flex justify-between items-center mb-8">
                       <h2 className="text-5xl font-black text-white italic graffiti-text text-pink-500">CHARACTER SHOP</h2>
                       <div className="bg-yellow-500 text-black px-4 py-2 rounded-full font-bold text-xl flex items-center gap-2 border-2 border-yellow-700">
                           {totalCoins.toLocaleString()} 
                           <div className="w-6 h-6 rounded-full bg-yellow-300 border border-yellow-800 flex items-center justify-center">
                                <span className="text-[10px] font-bold">$</span>
                           </div>
                       </div>
                   </div>

                   <div className="grid grid-cols-1 md:grid-cols-3 gap-6 overflow-y-auto pb-4 custom-scrollbar">
                       {CHARACTERS.map(char => {
                           const isOwned = ownedChars.includes(char.id);
                           const isSelected = selectedCharId === char.id;
                           
                           return (
                               <div key={char.id} className={`relative p-6 rounded-2xl border-4 transition-all duration-200 flex flex-col items-center gap-4 ${isSelected ? 'bg-gray-800 border-green-500 scale-105 shadow-[0_0_30px_#22c55e] z-10' : 'bg-gray-800 border-gray-600 hover:border-gray-400 hover:scale-[1.02]'}`}>
                                   {/* Character Preview */}
                                   <div className="w-32 h-40 relative flex items-end justify-center perspective-container">
                                        <div className={`w-20 h-28 ${char.colorPrimary} rounded-lg relative shadow-lg`}>
                                            <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-4 w-16 h-16 bg-amber-200 rounded-xl z-20">
                                                 <div className={`absolute -top-3 left-1/2 -translate-x-1/2 w-18 h-8 ${char.colorSecondary} rounded-t-xl`}></div>
                                            </div>
                                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 text-[10px] text-white/50 font-black">{char.name}</div>
                                        </div>
                                   </div>

                                   <div className="text-center w-full">
                                       <h3 className="text-2xl font-bold text-white uppercase italic">{char.name}</h3>
                                       {!isOwned && <p className="text-yellow-400 font-bold flex items-center justify-center gap-1">{char.cost} <span className="text-xs">COINS</span></p>}
                                   </div>

                                   {isOwned ? (
                                       <button 
                                            onClick={() => selectCharacter(char.id)}
                                            disabled={isSelected}
                                            className={`w-full py-3 rounded-lg font-bold uppercase tracking-wider ${isSelected ? 'bg-green-500 text-black shadow-[0_0_15px_rgba(34,197,94,0.5)]' : 'bg-gray-600 text-gray-300 hover:bg-white hover:text-black'}`}
                                       >
                                           {isSelected ? 'SELECTED' : 'SELECT'}
                                       </button>
                                   ) : (
                                       <button 
                                            onClick={() => buyCharacter(char.id, char.cost)}
                                            disabled={totalCoins < char.cost}
                                            className={`w-full py-3 rounded-lg font-bold uppercase flex items-center justify-center gap-2 transition-colors ${totalCoins >= char.cost ? 'bg-yellow-500 text-black hover:bg-yellow-400 shadow-[0_0_15px_rgba(234,179,8,0.5)]' : 'bg-gray-700 text-gray-500 cursor-not-allowed opacity-50'}`}
                                       >
                                           {totalCoins < char.cost ? <Lock size={18} /> : <ShoppingCart size={18} />}
                                           {totalCoins < char.cost ? 'Need Coins' : 'Buy'}
                                       </button>
                                   )}
                               </div>
                           );
                       })}
                   </div>

                   <button 
                        onClick={() => setShowShop(false)}
                        className="mt-6 self-center px-8 py-3 bg-white text-black font-bold uppercase tracking-widest rounded-full hover:bg-gray-200 hover:scale-105 transition-all shadow-lg"
                   >
                       Back to Menu
                   </button>
               </div>
           </div>
      )}

      {/* Game Over Screen */}
      {gameState === GameState.GAME_OVER && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/90 z-50 animate-in fade-in duration-300">
             <h2 className="text-7xl font-black text-red-500 uppercase tracking-tighter graffiti-text mb-2 animate-bounce drop-shadow-[0_0_10px_red]">BUSTED!</h2>
             <div className="bg-gray-800 p-8 rounded-2xl border-4 border-gray-600 shadow-2xl flex flex-col items-center w-80 transform rotate-1 hover:rotate-0 transition-transform">
                 <div className="text-gray-400 uppercase text-xs font-bold tracking-widest mb-1">Score</div>
                 <div className="text-5xl text-white font-black mb-6 drop-shadow-md">{metrics.score.toLocaleString()}</div>
                 
                 <div className="flex justify-between w-full mb-8 px-4 bg-gray-900/50 p-4 rounded-lg">
                     <div className="flex flex-col items-center">
                         <span className="text-yellow-400 font-bold text-xl">{metrics.coins}</span>
                         <span className="text-[10px] text-gray-500 tracking-wider">COINS</span>
                     </div>
                     <div className="flex flex-col items-center border-l border-gray-700 pl-4">
                         <span className="text-cyan-400 font-bold text-xl">{metrics.distance}m</span>
                         <span className="text-[10px] text-gray-500 tracking-wider">DIST</span>
                     </div>
                 </div>

                 <button 
                    onClick={startGame}
                    className="w-full py-4 bg-green-500 hover:bg-green-400 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-95 text-lg"
                 >
                    <RotateCcw size={24} /> Run Again
                 </button>
                 
                 <button 
                    onClick={() => setGameState(GameState.START)}
                    className="mt-6 text-gray-400 hover:text-white text-sm hover:underline"
                 >
                    Main Menu
                 </button>
             </div>
        </div>
      )}
    </div>
  );
};

export default App;
